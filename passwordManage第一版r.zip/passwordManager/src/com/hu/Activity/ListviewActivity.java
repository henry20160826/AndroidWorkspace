package com.hu.Activity;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;

import com.example.passwordmanager.R;
import com.hu.DataClass.All;
import com.hu.encode.Cipher;

import static com.hu.DataClass.Content.*;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.app.ActionBar;
import android.graphics.Color;
import android.opengl.Visibility;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class ListviewActivity extends Activity {

	private ListView listView;
	private ArrayList<HashMap<String, String>> arrayList;
	private SimpleAdapter adapter;
	private All all;
	private ImageButton addButton, menuButton, deleteButton;
	private int mode = LOOK;
	private ArrayList<String> deleteArrayList;
	private ActionBar actionBar;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list);
		actionBar = getActionBar();
		actionBar.show();
		getOverflowMenu();
		all = (All) getApplication();
		dealViews();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		reloadArrayList();
	}

	private void dealViews() {
		dealListview();
		dealButtons();
	}

	private void dealButtons() {
		addButton = (ImageButton) findViewById(R.id.ibt_add);
		addButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				toNewItem();
			}
		});
		deleteButton = (ImageButton) findViewById(R.id.bt_delete);
		deleteButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				deleteItems();
				reloadArrayList();
				relistbackground();
				mode = LOOK;
				deleteButton.setVisibility(View.GONE);
			}
		});
	}

	private void toNewItem() {
		Intent intent = new Intent();
		intent.setClass(ListviewActivity.this, EditActivity.class);
		intent.putExtra("mode", NEW);
		startActivity(intent);
	}

	private void toSettings() {
		Intent intent=new Intent();
		intent.setClass(ListviewActivity.this, SettingsActivity.class);
		startActivity(intent);
	}

	private void toAbout(){
		Intent intent=new Intent();
		intent.setClass(ListviewActivity.this, AboutActivity.class);
		startActivity(intent);
	}
	
	private void deleteItems() {
		int length = deleteArrayList.size();
		for (int i = 0; i < length; i++) {
			all.dbManager.deleteOneItem(deleteArrayList.get(i));
		}
	}

	private void dealListview() {
		// TODO ���ز�����ListView�ؼ�
		listView = (ListView) findViewById(R.id.listView1);
		arrayList = new ArrayList<HashMap<String, String>>();
		// adapter = new SimpleAdapter(this, arrayList, R.layout.listitem,
		// new String[] { "place", "name", "p", }, new int[] {
		// R.id.tv_place, R.id.tv_name, R.id.tv_p });
		adapter = new SimpleAdapter(this, arrayList, R.layout.listitem,
				new String[] { "place", "pkey" }, new int[] { R.id.tv_place,
						R.id.tv_pkey });
		listView.setAdapter(adapter);

		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO ����ListView��Ŀʱ�Ĵ�������
				if (LOOK == mode) {
					Intent intent = new Intent();
					intent.setClass(ListviewActivity.this, EditActivity.class);

					intent.putExtra("mode", EDIT);
					intent.putExtra("pkey", arrayList.get(arg2).get("pkey"));

					startActivityForResult(intent, 0);
					// editnum = arg2;
					// startActivity(intent);
				}
				if (EDIT == mode) {
					String pkey = arrayList.get(arg2).get("pkey");
					int num = existInDeleteArrayList(pkey);
					if (-1 == num) {
						arg1.setBackgroundColor(getResources().getColor(
								R.color.bule));
						deleteArrayList.add(pkey);
					} else {
						arg1.setBackgroundColor(Color.TRANSPARENT);
						deleteArrayList.remove(num);
					}
				}
			}
		});
		listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					final int arg2, long arg3) {
				// TODO ����ListView��Ŀʱ�Ĵ�������
				// new AlertDialog.Builder(ListviewActivity.this)
				// .setTitle("��ʾ")
				// .setMessage("�Ƿ�Ҫɾ����Ϣ��")
				// .setPositiveButton("ɾ��",
				// new DialogInterface.OnClickListener() {
				// @Override
				// public void onClick(DialogInterface dialog,
				// int which) {
				// // TODO ����ɾ������
				// // deleteItem(arg2);
				// }
				//
				// })
				// .setNegativeButton("ȡ��",
				// new DialogInterface.OnClickListener() {
				// @Override
				// public void onClick(DialogInterface dialog,
				// int which) {
				// // TODO ȡ��ɾ��
				//
				// }
				// }).show();
				if (LOOK == mode) {
					mode = EDIT;
					deleteButton.setVisibility(View.VISIBLE);
					deleteArrayList = new ArrayList<String>();
					arg1.setBackgroundColor(getResources().getColor(
							R.color.bule));
					deleteArrayList.add(arrayList.get(arg2).get("pkey"));
					return true;
				}
				return false;
			}
		});
	}

	private int existInDeleteArrayList(String string) {
		int length = deleteArrayList.size();
		for (int i = 0; i < length; i++) {
			if (deleteArrayList.get(i).equals(string)) {
				return i;
			}
		}
		return -1;
	}

	private void reloadArrayList() {
		// TODO ˢ��ListView�е�����
		arrayList.clear();
		Cursor cursor = all.dbManager.getPasswords();
		String placeString = null;
		while (cursor.moveToNext()) {
			HashMap<String, String> map = new HashMap<String, String>();
			placeString = Cipher.decode(cursor.getString(cursor
					.getColumnIndex("place")));
			map.put("place", placeString);
			map.put("pkey", cursor.getString(cursor.getColumnIndex("pkey")));
			// map.put("name", cursor.getString(cursor.getColumnIndex("name")));
			// map.put("p", cursor.getString(cursor.getColumnIndex("p")));
			arrayList.add(map);
		}
		adapter.notifyDataSetChanged();
		if (cursor.getCount() == 0) {
			Toast.makeText(ListviewActivity.this, "����Ϊ��", Toast.LENGTH_LONG)
					.show();
		}
	}

	private void relistbackground() {
		int length = listView.getChildCount();
		for (int i = 0; i < length; i++) {
			listView.getChildAt(i).setBackgroundColor(Color.TRANSPARENT);
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK && EDIT == mode) {
			mode = LOOK;
			relistbackground();
			deleteButton.setVisibility(View.GONE);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.overflow, menu);
		super.onCreateOptionsMenu(menu);
		// ���Ӳ˵���
		// MenuItem add = menu.add(0, 0, 0, "add");
		// MenuItem del = menu.add(0, 0, 0, "del");
		// MenuItem save = menu.add(0, 0, 0, "save");
		// MenuItem save1 = menu.add(0, 0, 0, "save");
		// MenuItem save2 = menu.add(0, 0, 0, "save");
		// MenuItem save3 = menu.add(0, 0, 0, "save");
		// MenuItem item=menu.add(groupId, itemId, order, title)
		// �󶨵�ActionBar
		// add.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		// del.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		// save.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		// save1.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		// save2.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		// save3.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);

		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.add:
			toNewItem();
			break;
		case R.id.settings:
			toSettings();
			break;
		case R.id.about:
			toAbout();
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private void getOverflowMenu() {

		try {
			ViewConfiguration config = ViewConfiguration.get(this);
			Field menuKeyField = ViewConfiguration.class
					.getDeclaredField("sHasPermanentMenuKey");
			if (menuKeyField != null) {
				menuKeyField.setAccessible(true);
				menuKeyField.setBoolean(config, false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
