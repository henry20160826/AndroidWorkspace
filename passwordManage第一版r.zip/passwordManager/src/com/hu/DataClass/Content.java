package com.hu.DataClass;

public class Content {
	// TODO ģʽ����
	public final static int EDIT = 464575;
	public final static int NEW = 678567;
	public final static int LOOK = 435354;
}
