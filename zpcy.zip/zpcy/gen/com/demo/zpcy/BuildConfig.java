/** Automatically generated file. DO NOT MODIFY */
package com.demo.zpcy;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}