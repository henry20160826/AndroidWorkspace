/** Automatically generated file. DO NOT MODIFY */
package com.hu.toupiaoc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}