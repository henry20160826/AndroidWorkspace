package com.hu.DataClass;

public class Content {
	// TODO ģʽ����
	public static final int ADD = 010101;
	public static final int EDIT = 110000;
	public static final int LOOKUP = 16262;
	public static final int STUDENT = 111111;
	public static final int ELECTION = 976344;

	// TODO �������ӳ���
	public static final int NET_CONNECT_HOPE = 793545;
	public static final int NET_CONNECT_OK = 7964646;
	public static final int NET_WANT_DATA = 634245;
	public static final int NET_RECEIVED_OK = 634598;
	public static final int NET_SEND_DATA = 434646;
	public static final int NET_SEND_VOTE = 7114343;
	public static final int NET_HAVE_VOTED = 8934342;

	public static final int ERROR = 4356433;

	public static final int SERVEICE_PORT = 4000;
	public static final int CLIENT_PORT = 3000;

	// TODO ������Ϣ�ָ��
	public static final String SPLIT_TYPE_INFO = "#";
	public static final String SPLIT_INFO_BIG = "@";
	public static final String SPLIT_INFO_MID = ";";
	public static final String SPLIT_INFO_SML = ",";

	// TODO ���Ų�ѯ����
	/**
	 * ���еĶ���
	 */
	public static final String SMS_URI_ALL = "content://sms/";
	/**
	 * �ռ������
	 */
	public static final String SMS_URI_INBOX = "content://sms/inbox";
	/**
	 * ���������
	 */
	public static final String SMS_URI_SEND = "content://sms/sent";
	/**
	 * �ݸ������
	 */
	public static final String SMS_URI_DRAFT = "content://sms/draft";
}
