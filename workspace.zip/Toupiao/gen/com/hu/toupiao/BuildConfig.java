/** Automatically generated file. DO NOT MODIFY */
package com.hu.toupiao;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}