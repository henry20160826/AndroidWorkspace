package com.hu.DataClass;

public class Winner {
	public String sid;
	public int eid;

	public Winner(String sid, int eid) {
		// TODO Auto-generated constructor stub
		this.eid = eid;
		this.sid = sid;
	}
}
