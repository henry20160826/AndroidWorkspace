package com.hu.dataclass;

public class Communication {
	// ������ip
	public final static String SERVER_IP = "192.168.191.1";

	// �˿�
	public final static int COMMUNICATION_PORT = 5555;

	public final static String GET_KEYWORD = "#";
	public final static String GET_INFO=",";

	public final static int NAME_AND_PASSWORD = 111;
	public final static int DISHES=222;
}
