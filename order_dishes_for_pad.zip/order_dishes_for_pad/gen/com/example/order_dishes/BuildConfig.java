/** Automatically generated file. DO NOT MODIFY */
package com.example.order_dishes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}