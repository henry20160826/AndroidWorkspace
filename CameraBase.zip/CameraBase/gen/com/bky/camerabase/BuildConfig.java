/** Automatically generated file. DO NOT MODIFY */
package com.bky.camerabase;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}